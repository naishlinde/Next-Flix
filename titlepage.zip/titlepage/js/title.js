var buttonToFruit = $('#eyes');

buttonToFruit.click(function() {
  window.location = "js/fruitpage/fruit.html"
});
